using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using BattleZone3D;

public static class MobileHUDBuilder
{
    [MenuItem("Tools/Battle Zone 3D/Create Mobile HUD")]
    public static void CreateMobileHud()
    {
        Canvas existing = Object.FindObjectOfType<Canvas>();
        if (existing)
        {
            if (!EditorUtility.DisplayDialog("Mobile HUD", "A Canvas already exists. Create another HUD anyway?", "Create", "Cancel"))
                return;
        }

        var canvasObject = new GameObject("BattleZone Mobile HUD",
            typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.5f;

        if (!Object.FindObjectOfType<EventSystem>())
        {
            var es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            Undo.RegisterCreatedObjectUndo(es, "Create EventSystem");
        }

        // Transparent right-side panel for camera swipe; buttons are created after it.
        GameObject look = CreateRect("Look Area", canvas.transform,
            new Vector2(0.42f, 0.04f), new Vector2(1f, 0.96f),
            Vector2.zero, Vector2.zero, new Color(1f, 1f, 1f, 0.01f));
        look.AddComponent<TouchLookArea>();

        GameObject stick = CreateRect("Movement Joystick", canvas.transform,
            new Vector2(0.07f, 0.08f), new Vector2(0.07f, 0.08f),
            new Vector2(0f, 0f), new Vector2(220f, 220f), new Color(0.1f, 0.1f, 0.1f, 0.38f));
        VirtualJoystick joystick = stick.AddComponent<VirtualJoystick>();

        GameObject handle = CreateRect("Joystick Handle", stick.transform,
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(88f, 88f), new Color(0.85f, 0.9f, 1f, 0.65f));
        joystick.SetHandle(handle.GetComponent<RectTransform>());

        CreateAction(canvas.transform, "RUN", MobileAction.Run, new Vector2(0.19f, 0.43f), new Vector2(112f, 112f));
        CreateAction(canvas.transform, "JUMP", MobileAction.Jump, new Vector2(0.72f, 0.20f), new Vector2(112f, 112f));
        CreateAction(canvas.transform, "CROUCH", MobileAction.Crouch, new Vector2(0.73f, 0.40f), new Vector2(100f, 100f));
        CreateAction(canvas.transform, "AIM", MobileAction.Aim, new Vector2(0.88f, 0.48f), new Vector2(118f, 118f));
        CreateAction(canvas.transform, "FIRE", MobileAction.Fire, new Vector2(0.88f, 0.22f), new Vector2(150f, 150f));
        CreateAction(canvas.transform, "RELOAD", MobileAction.Reload, new Vector2(0.88f, 0.70f), new Vector2(92f, 92f));

        Undo.RegisterCreatedObjectUndo(canvasObject, "Create Battle Zone Mobile HUD");
        Selection.activeGameObject = canvasObject;
        Debug.Log("Mobile HUD created. Add MobileControlBinder to the local player and assign references.");
    }

    [MenuItem("Tools/Battle Zone 3D/Configure Android Landscape")]
    public static void ConfigureLandscape()
    {
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToPortrait = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        PlayerSettings.allowedAutorotateToLandscapeLeft = true;
        PlayerSettings.allowedAutorotateToLandscapeRight = true;
        PlayerSettings.productName = "BATTLE ZONE 3D";
        PlayerSettings.applicationIdentifier = "com.example.battlezone3d";
        Debug.Log("Android landscape configured. Change the sample package identifier before publishing.");
    }

    static GameObject CreateAction(Transform parent, string label, MobileAction action, Vector2 anchor, Vector2 size)
    {
        GameObject button = CreateRect(label + " Button", parent, anchor, anchor, Vector2.zero, size,
            new Color(0.05f, 0.08f, 0.12f, 0.68f));
        button.AddComponent<MobileActionButton>().Configure(action);

        GameObject textObject = new GameObject("Label", typeof(RectTransform), typeof(Text));
        textObject.transform.SetParent(button.transform, false);
        RectTransform textRect = textObject.GetComponent<RectTransform>();
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = Vector2.zero;
        textRect.offsetMax = Vector2.zero;

        Text text = textObject.GetComponent<Text>();
        text.text = label;
        text.alignment = TextAnchor.MiddleCenter;
        text.color = Color.white;
        text.fontSize = 27;
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.raycastTarget = false;
        return button;
    }

    static GameObject CreateRect(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax,
        Vector2 anchoredPosition, Vector2 size, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rect = go.GetComponent<RectTransform>();
        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.anchoredPosition = anchoredPosition;
        rect.sizeDelta = size;
        Image image = go.GetComponent<Image>();
        image.color = color;
        image.raycastTarget = true;
        return go;
    }
}
