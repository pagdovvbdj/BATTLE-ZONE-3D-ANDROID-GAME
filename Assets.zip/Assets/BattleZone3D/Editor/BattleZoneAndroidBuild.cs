using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class BattleZoneAndroidBuild
{
    [MenuItem("Tools/Battle Zone 3D/Build Android APK")]
    public static void BuildApk()
    {
        if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
        {
            bool switched = EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            EditorUtility.DisplayDialog("BATTLE ZONE 3D",
                switched
                    ? "تم التحويل إلى Android. شغّل أمر Build Android APK مرة أخرى."
                    : "تعذر التحويل إلى Android. تأكد من تثبيت Android Build Support من Unity Hub.",
                "موافق");
            return;
        }

        if (EditorBuildSettings.scenes.Length == 0)
        {
            EditorUtility.DisplayDialog("BATTLE ZONE 3D", "أضف مشهداً إلى Build Settings أولاً.", "موافق");
            return;
        }

        EditorUserBuildSettings.buildAppBundle = false; // Build an APK for this prototype.
        string outputDirectory = "Builds/Android";
        Directory.CreateDirectory(outputDirectory);
        string outputPath = Path.Combine(outputDirectory, "BattleZone3D.apk");

        var options = new BuildPlayerOptions
        {
            scenes = System.Array.ConvertAll(EditorBuildSettings.scenes, scene => scene.path),
            locationPathName = outputPath,
            target = BuildTarget.Android,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result == BuildResult.Succeeded)
            EditorUtility.DisplayDialog("BATTLE ZONE 3D", "تم إنشاء APK:\n" + outputPath, "موافق");
        else
            EditorUtility.DisplayDialog("BATTLE ZONE 3D",
                "لم يكتمل البناء. راجع Console وBuild Report.\n" + report.summary.result,
                "موافق");
    }
}
