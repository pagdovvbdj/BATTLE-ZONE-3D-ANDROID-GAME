using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using BattleZone3D;
using System.IO;

public static class PrototypeSceneBuilder
{
    [MenuItem("Tools/Battle Zone 3D/Create Prototype Scene")]
    public static void Create()
    {
        const string folder = "Assets/BattleZone3D/Scenes";
        if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Prototype Ground";
        ground.transform.localScale = new Vector3(8, 1, 8);

        var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Local Player";
        player.transform.position = new Vector3(0, 1.1f, 0);
        var controller = player.AddComponent<CharacterController>();
        controller.height = 2f;
        controller.radius = 0.42f;
        player.AddComponent<PlayerMotor>();
        player.AddComponent<EnergyBlaster>();
        player.AddComponent<MobileControlBinder>();

        var cameraObject = new GameObject("Third Person Camera");
        var camera = cameraObject.AddComponent<Camera>();
        camera.tag = "MainCamera";
        cameraObject.AddComponent<AudioListener>();
        var follow = cameraObject.AddComponent<ThirdPersonCamera>();
        follow.SetTarget(player.transform);
        player.GetComponent<PlayerMotor>().SetCamera(cameraObject.transform);

        var lightObject = new GameObject("Directional Light");
        var light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.2f;
        lightObject.transform.rotation = Quaternion.Euler(50, -30, 0);

        EditorSceneManager.SaveScene(scene, folder + "/BattleZone_Prototype.unity");
        EditorBuildSettings.scenes = new[] {
            new EditorBuildSettingsScene(folder + "/BattleZone_Prototype.unity", true)
        };
        AssetDatabase.SaveAssets();
        Debug.Log("Battle Zone 3D prototype scene created.");
    }
}
