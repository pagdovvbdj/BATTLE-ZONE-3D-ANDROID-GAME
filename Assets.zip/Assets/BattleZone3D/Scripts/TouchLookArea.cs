using UnityEngine;
using UnityEngine.EventSystems;

namespace BattleZone3D
{
    // Attach to a transparent UI Image on the right side of the screen.
    public class TouchLookArea : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [SerializeField] float sensitivity = 0.12f;
        [SerializeField] bool invertY;
        int activePointer = int.MinValue;
        Vector2 lastPosition;

        public void OnPointerDown(PointerEventData eventData)
        {
            activePointer = eventData.pointerId;
            lastPosition = eventData.position;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (eventData.pointerId != activePointer) return;
            Vector2 delta = eventData.position - lastPosition;
            lastPosition = eventData.position;
            if (invertY) delta.y = -delta.y;
            MobileInputState.Look += delta * sensitivity;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            if (eventData.pointerId == activePointer) activePointer = int.MinValue;
        }

        public void SetSensitivity(float value) => sensitivity = Mathf.Clamp(value, 0.02f, 0.5f);
    }
}
