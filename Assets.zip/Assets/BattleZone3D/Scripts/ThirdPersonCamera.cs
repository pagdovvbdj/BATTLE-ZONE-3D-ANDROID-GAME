using UnityEngine;

namespace BattleZone3D
{
    public class ThirdPersonCamera : MonoBehaviour
    {
        [Header("Target")]
        [SerializeField] Transform target;
        [SerializeField] Vector3 shoulderOffset = new Vector3(0.62f, 1.55f, 0f);
        [SerializeField] float distance = 4.2f;
        [SerializeField] float aimDistance = 2.8f;

        [Header("Look")]
        [SerializeField] float sensitivity = 2.2f;
        [SerializeField] float minPitch = -25f;
        [SerializeField] float maxPitch = 65f;

        [Header("Aim")]
        [SerializeField] float normalFov = 60f;
        [SerializeField] float aimFov = 48f;
        [SerializeField] float aimLerpSpeed = 12f;

        float yaw;
        float pitch = 12f;
        bool aiming;
        Camera cachedCamera;

        void Awake()
        {
            cachedCamera = GetComponent<Camera>();
            if (target) yaw = target.eulerAngles.y;
            if (cachedCamera) cachedCamera.fieldOfView = normalFov;
        }

        public void SetTarget(Transform value)
        {
            target = value;
            if (target) yaw = target.eulerAngles.y;
        }

        public void SetAiming(bool value) => aiming = value;

        public void AddLookInput(Vector2 delta)
        {
            yaw += delta.x * sensitivity;
            pitch = Mathf.Clamp(pitch - delta.y * sensitivity, minPitch, maxPitch);
        }

        public void SetSensitivity(float value) => sensitivity = Mathf.Clamp(value, 0.2f, 5f);

        void LateUpdate()
        {
            if (!target) return;

#if UNITY_EDITOR || UNITY_STANDALONE
            if (Input.GetMouseButton(1))
                AddLookInput(new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * 30f);
#endif

            float currentDistance = aiming ? aimDistance : distance;
            float desiredFov = aiming ? aimFov : normalFov;
            if (cachedCamera)
                cachedCamera.fieldOfView = Mathf.Lerp(cachedCamera.fieldOfView, desiredFov, aimLerpSpeed * Time.deltaTime);

            Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 pivot = target.position + Vector3.up * shoulderOffset.y;
            Vector3 offset = shoulderOffset + Vector3.back * currentDistance;
            Vector3 desired = pivot + rotation * offset;

            // Basic camera obstruction handling.
            Vector3 direction = desired - pivot;
            float length = direction.magnitude;
            if (length > 0.01f && Physics.SphereCast(pivot, 0.18f, direction.normalized,
                    out RaycastHit hit, length, ~0, QueryTriggerInteraction.Ignore))
            {
                if (hit.transform != target && !hit.transform.IsChildOf(target))
                    desired = pivot + direction.normalized * Mathf.Max(0.35f, hit.distance - 0.08f);
            }

            transform.position = desired;
            transform.rotation = rotation;
        }
    }
}
