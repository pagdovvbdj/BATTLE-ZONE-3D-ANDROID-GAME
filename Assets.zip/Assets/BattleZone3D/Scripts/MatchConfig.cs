using UnityEngine;

namespace BattleZone3D
{
    public enum MatchMode { Duel1v1, Team2v2, Team3v3, Team4v4, BattleRoyale }

    [CreateAssetMenu(menuName = "Battle Zone 3D/Match Config")]
    public class MatchConfig : ScriptableObject
    {
        public MatchMode mode = MatchMode.BattleRoyale;
        [Range(2, 20)] public int maxPlayers = 20;
        public string mapId = "TropicalIsland";
        public bool privateRoom;
        public bool passwordRequired;
    }
}
