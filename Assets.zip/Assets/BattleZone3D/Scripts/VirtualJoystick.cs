using UnityEngine;
using UnityEngine.EventSystems;

namespace BattleZone3D
{
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [SerializeField] RectTransform handle;
        [SerializeField] float radius = 72f;
        [Range(0.1f, 1f)] [SerializeField] float deadZone = 0.12f;
        RectTransform rect;

        void Awake() { rect = transform as RectTransform; }
        public void SetHandle(RectTransform value) => handle = value;
        public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

        public void OnDrag(PointerEventData eventData)
        {
            if (!rect) return;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                rect, eventData.position, eventData.pressEventCamera, out Vector2 local);
            Vector2 value = Vector2.ClampMagnitude(local / Mathf.Max(1f, radius), 1f);
            if (value.magnitude < deadZone) value = Vector2.zero;
            MobileInputState.Move = value;
            if (handle) handle.anchoredPosition = value * radius;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            MobileInputState.Move = Vector2.zero;
            if (handle) handle.anchoredPosition = Vector2.zero;
        }
    }
}
