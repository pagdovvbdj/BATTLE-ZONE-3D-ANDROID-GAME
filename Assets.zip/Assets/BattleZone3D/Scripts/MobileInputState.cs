using UnityEngine;

namespace BattleZone3D
{
    public static class MobileInputState
    {
        public static Vector2 Move;
        public static Vector2 Look;
        public static bool RunHeld;
        public static bool AimHeld;
        public static bool FireHeld;
        public static bool JumpPressed;
        public static bool CrouchTogglePressed;
        public static bool ReloadPressed;

        // Called once after the local player has consumed one-frame actions.
        public static void ResetFrame()
        {
            Look = Vector2.zero;
            JumpPressed = false;
            CrouchTogglePressed = false;
            ReloadPressed = false;
        }
    }
}
