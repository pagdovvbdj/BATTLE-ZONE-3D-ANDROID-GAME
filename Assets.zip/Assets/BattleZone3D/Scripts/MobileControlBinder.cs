using UnityEngine;

namespace BattleZone3D
{
    // Attach to the local player. Assign references in Inspector when possible.
    public class MobileControlBinder : MonoBehaviour
    {
        [SerializeField] PlayerMotor motor;
        [SerializeField] ThirdPersonCamera thirdPersonCamera;
        [SerializeField] EnergyBlaster blaster;

        void Awake()
        {
            if (!motor) motor = GetComponent<PlayerMotor>();
            if (!thirdPersonCamera && Camera.main)
                thirdPersonCamera = Camera.main.GetComponent<ThirdPersonCamera>();
            if (!blaster) blaster = GetComponent<EnergyBlaster>();

            if (motor && Camera.main) motor.SetCamera(Camera.main.transform);
            if (blaster && Camera.main) blaster.SetAimCamera(Camera.main);
        }

        void Update()
        {
            if (motor)
            {
                motor.SetMobileMove(MobileInputState.Move);
                motor.SetRun(MobileInputState.RunHeld);
            }
        }

        void LateUpdate()
        {
            if (thirdPersonCamera)
            {
                if (MobileInputState.Look.sqrMagnitude > 0f)
                    thirdPersonCamera.AddLookInput(MobileInputState.Look);
                thirdPersonCamera.SetAiming(MobileInputState.AimHeld);
            }

            if (motor && MobileInputState.JumpPressed) motor.Jump();
            if (motor && MobileInputState.CrouchTogglePressed) motor.ToggleCrouch();
            if (blaster)
            {
                if (MobileInputState.FireHeld) blaster.Fire();
                if (MobileInputState.ReloadPressed) blaster.Reload();
            }

            MobileInputState.ResetFrame();
        }
    }
}
