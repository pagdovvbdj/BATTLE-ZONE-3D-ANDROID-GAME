using UnityEngine;
using UnityEngine.EventSystems;

namespace BattleZone3D
{
    public enum MobileAction { Fire, Aim, Run, Jump, Crouch, Reload }

    public class MobileActionButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler
    {
        [SerializeField] MobileAction action;
        public void Configure(MobileAction value) => action = value;

        public void OnPointerDown(PointerEventData eventData)
        {
            if (action == MobileAction.Fire) MobileInputState.FireHeld = true;
            if (action == MobileAction.Aim) MobileInputState.AimHeld = true;
            if (action == MobileAction.Run) MobileInputState.RunHeld = true;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            if (action == MobileAction.Fire) MobileInputState.FireHeld = false;
            if (action == MobileAction.Aim) MobileInputState.AimHeld = false;
            if (action == MobileAction.Run) MobileInputState.RunHeld = false;
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (action == MobileAction.Jump) MobileInputState.JumpPressed = true;
            if (action == MobileAction.Crouch) MobileInputState.CrouchTogglePressed = true;
            if (action == MobileAction.Reload) MobileInputState.ReloadPressed = true;
        }
    }
}
