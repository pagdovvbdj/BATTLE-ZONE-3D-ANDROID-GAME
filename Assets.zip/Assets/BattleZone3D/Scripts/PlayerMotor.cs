using UnityEngine;

namespace BattleZone3D
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerMotor : MonoBehaviour
    {
        [Header("Movement")]
        [SerializeField] float walkSpeed = 4.2f;
        [SerializeField] float runSpeed = 6.2f;
        [SerializeField] float crouchSpeed = 2.2f;
        [SerializeField] float jumpHeight = 1.15f;
        [SerializeField] float gravity = -22f;

        [Header("References")]
        [SerializeField] Transform cameraTransform;

        [Header("Crouch")]
        [SerializeField] float standingHeight = 2f;
        [SerializeField] float crouchingHeight = 1.2f;

        CharacterController controller;
        Vector3 verticalVelocity;
        Vector2 mobileMove;
        bool runHeld;
        bool jumpQueued;
        bool crouched;

        void Awake()
        {
            controller = GetComponent<CharacterController>();
            standingHeight = Mathf.Max(standingHeight, controller.height);
            if (!cameraTransform && Camera.main) cameraTransform = Camera.main.transform;
        }

        void Update()
        {
            if (!controller) return;

            Vector2 input = mobileMove;
#if UNITY_EDITOR || UNITY_STANDALONE
            if (input.sqrMagnitude < 0.001f)
                input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            if (Input.GetKeyDown(KeyCode.Space)) jumpQueued = true;
            bool keyboardRun = Input.GetKey(KeyCode.LeftShift);
#else
            bool keyboardRun = false;
#endif

            Vector3 move;
            if (cameraTransform)
            {
                Vector3 forward = Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized;
                Vector3 right = Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized;
                move = Vector3.ClampMagnitude(forward * input.y + right * input.x, 1f);
            }
            else
            {
                move = Vector3.ClampMagnitude(transform.forward * input.y + transform.right * input.x, 1f);
            }

            float speed = crouched ? crouchSpeed : ((runHeld || keyboardRun) ? runSpeed : walkSpeed);
            controller.Move(move * speed * Time.deltaTime);

            if (move.sqrMagnitude > 0.01f)
            {
                Quaternion target = Quaternion.LookRotation(move, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, target, 12f * Time.deltaTime);
            }

            if (controller.isGrounded && verticalVelocity.y < 0f) verticalVelocity.y = -2f;
            if (jumpQueued && controller.isGrounded && !crouched)
                verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
            jumpQueued = false;

            verticalVelocity.y += gravity * Time.deltaTime;
            controller.Move(verticalVelocity * Time.deltaTime);
        }

        public void SetMobileMove(Vector2 value) => mobileMove = Vector2.ClampMagnitude(value, 1f);
        public void SetRun(bool held) => runHeld = held;
        public void Jump() => jumpQueued = true;
        public void SetCamera(Transform target) => cameraTransform = target;

        public void ToggleCrouch()
        {
            crouched = !crouched;
            float newHeight = crouched ? crouchingHeight : standingHeight;
            controller.height = newHeight;
            Vector3 center = controller.center;
            center.y = newHeight * 0.5f;
            controller.center = center;
        }
    }
}
