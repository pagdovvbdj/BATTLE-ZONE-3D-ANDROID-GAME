using UnityEngine;

namespace BattleZone3D
{
    // Fictional, non-realistic energy projectile for a non-graphic arcade prototype.
    public class EnergyBlaster : MonoBehaviour
    {
        [SerializeField] Camera aimCamera;
        [SerializeField] GameObject orbPrefab;
        [SerializeField] float launchSpeed = 24f;
        [SerializeField] float cooldown = 0.35f;
        [SerializeField] int magazineSize = 20;
        [SerializeField] float reloadDuration = 1.1f;

        int ammo;
        float nextShot;
        bool reloading;
        float reloadEndsAt;

        void Awake() { ammo = magazineSize; }

        void Update()
        {
#if UNITY_EDITOR || UNITY_STANDALONE
            if (Input.GetMouseButton(0)) Fire();
#endif
            if (reloading && Time.time >= reloadEndsAt)
            {
                ammo = magazineSize;
                reloading = false;
            }
        }

        public void Fire()
        {
            if (Time.time < nextShot || reloading || ammo <= 0 || !aimCamera) return;
            nextShot = Time.time + cooldown;
            ammo--;
            GameObject orb;
            if (orbPrefab)
            {
                orb = Instantiate(orbPrefab,
                    aimCamera.transform.position + aimCamera.transform.forward * 0.7f,
                    aimCamera.transform.rotation);
            }
            else
            {
                orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                orb.name = "Arcade Energy Orb";
                orb.transform.position = aimCamera.transform.position + aimCamera.transform.forward * 0.7f;
                orb.transform.rotation = aimCamera.transform.rotation;
                orb.transform.localScale = Vector3.one * 0.22f;
                var renderer = orb.GetComponent<Renderer>();
                if (renderer)
                {
                    var material = new Material(Shader.Find("Standard"));
                    material.color = new Color(0.15f, 0.85f, 1f, 1f);
                    material.EnableKeyword("_EMISSION");
                    material.SetColor("_EmissionColor", new Color(0.05f, 0.55f, 1f, 1f));
                    renderer.material = material;
                }
            }

            Rigidbody body = orb.GetComponent<Rigidbody>();
            if (!body) body = orb.AddComponent<Rigidbody>();
            body.useGravity = false;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            body.velocity = aimCamera.transform.forward * launchSpeed;
            Destroy(orb, 3.5f);
        }

        public void Reload()
        {
            if (reloading || ammo >= magazineSize) return;
            reloading = true;
            reloadEndsAt = Time.time + reloadDuration;
        }

        public void SetAimCamera(Camera value) => aimCamera = value;
        public int CurrentAmmo => ammo;
        public int MagazineSize => magazineSize;
        public bool IsReloading => reloading;
    }
}
