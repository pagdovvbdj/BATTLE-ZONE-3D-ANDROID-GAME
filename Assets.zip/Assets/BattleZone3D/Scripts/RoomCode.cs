using System;
using UnityEngine;

namespace BattleZone3D
{
    // Local room-code utility only. This does NOT create an online room.
    public static class RoomCode
    {
        const string Alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        public static string Generate(int length = 6)
        {
            length = Mathf.Clamp(length, 4, 10);
            var random = new System.Random();
            char[] chars = new char[length];
            for (int i = 0; i < length; i++)
                chars[i] = Alphabet[random.Next(Alphabet.Length)];
            return new string(chars);
        }
    }
}
